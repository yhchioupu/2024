import pygame
import random
import sys

# Initialize Pygame
pygame.init()

# Initialize the mixer
pygame.mixer.init()

# Load sounds
wing_sound = pygame.mixer.Sound("sounds/wing_sound.mp3")
die_sound = pygame.mixer.Sound("sounds/die_sound.mp3")
point_sound = pygame.mixer.Sound("sounds/point_sound.mp3")

# Load background music
pygame.mixer.music.load("sounds/background.mp3")
pygame.mixer.music.set_volume(0.1)
pygame.mixer.music.play(loops=-1)

# Screen settings
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Flappy Bird")

# Clock and FPS
clock = pygame.time.Clock()
FPS = 60

# Colors and font
WHITE = (255, 255, 255)
FONT = pygame.font.SysFont('Arial', 30, bold=True)

# Load images
BIRD_SPRITE_SHEET = pygame.transform.scale(pygame.image.load("images/CS1110_BirdSprite.png"), (200, 70))
PIPE_IMG = pygame.transform.scale(pygame.image.load("images/CS1110_MarioPipe.png"), (80, 500))
PIPE_IMG_REV = pygame.transform.flip(PIPE_IMG, False, True)
BG_IMG_1 = pygame.transform.scale(pygame.image.load("images/background.png"), (SCREEN_WIDTH, SCREEN_HEIGHT))
BG_IMG_2 = pygame.transform.scale(pygame.image.load("images/Background2.png"), (SCREEN_WIDTH, SCREEN_HEIGHT))
START_SCREEN_IMG = pygame.transform.scale(pygame.image.load("images/message.png"), (SCREEN_WIDTH, SCREEN_HEIGHT))

# Life icon
LIFE_ICON_IMG = pygame.image.load("images/life.png")
LIFE_ICON_SIZE = 50
LIFE_ICON_IMG = pygame.transform.scale(LIFE_ICON_IMG, (LIFE_ICON_SIZE, LIFE_ICON_SIZE))


class Bird:
    def __init__(self):
        self.frames = self.slice_sprite_sheet(BIRD_SPRITE_SHEET, 4)
        self.current_frame = 0
        self.image = self.frames[self.current_frame]
        self.rect = self.image.get_rect(center=(100, SCREEN_HEIGHT // 2))
        self.velocity = 0
        self.gravity = 0.5
        self.flap_speed = 5
        self.flap_counter = 0

    def slice_sprite_sheet(self, sprite_sheet, num_frames):
        frame_width = sprite_sheet.get_width() // num_frames
        frame_height = sprite_sheet.get_height()
        frames = [sprite_sheet.subsurface(pygame.Rect(i * frame_width, 0, frame_width, frame_height))
                  for i in range(num_frames)]
        return frames

    def update(self):
        # Flapping animation
        self.flap_counter = (self.flap_counter + 1) % self.flap_speed
        if self.flap_counter == 0:
            self.current_frame = (self.current_frame + 1) % len(self.frames)
            self.image = self.frames[self.current_frame]

        # Bird physics stuff
        self.velocity += self.gravity
        self.rect.y += int(self.velocity)
        if self.rect.bottom > SCREEN_HEIGHT:
            self.rect.bottom = SCREEN_HEIGHT
        if self.rect.top < 0:
            self.rect.top = 0

    # jump and jump height
    def jump(self):
        self.velocity = -10

    def draw(self):
        screen.blit(self.image, self.rect)

class Swallow:
    def __init__(self):
        self.image = pygame.image.load("images/swallow.png")
        self.image = pygame.transform.scale(self.image, (50, 50))  # Scale the image for better fit
        self.rect = self.image.get_rect()
        self.rect.y = random.randint(50, SCREEN_HEIGHT - 50)  # Random vertical spawn position
        self.rect.x = -50  # Start outside the screen on the left
        self.velocity = Pipe.VELOCITY * 1.35  # Swallow is faster than pipes

    def move(self):
        self.rect.x += self.velocity  # Move swallow from left to right

    def draw(self):
        screen.blit(self.image, self.rect)

    def collide(self, bird):
        bird_mask = pygame.mask.from_surface(bird.image)
        swallow_mask = pygame.mask.from_surface(self.image)
        offset = (self.rect.x - bird.rect.left, self.rect.y - round(bird.rect.top))

        if bird_mask.overlap(swallow_mask, offset):
            return True
        return False

class Star:
    def __init__(self, star_type):
        self.star_type = star_type
        if self.star_type == "yellow":
            self.image = pygame.image.load("images/yellow_star.png")
        elif self.star_type == "red":
            self.image = pygame.image.load("images/red_star.png")
        self.image = pygame.transform.scale(self.image, (50, 50))  # Scale the star
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(0, SCREEN_WIDTH - self.rect.width)  # Random x position
        self.rect.y = random.randint(0, SCREEN_HEIGHT - self.rect.height)  # Random y position
        self.velocity = Pipe.VELOCITY

    def move(self):
        self.rect.x -= self.velocity  # Move left like pipes and swallows

    def draw(self):
        screen.blit(self.image, self.rect)

    def collide(self, bird):
        bird_mask = pygame.mask.from_surface(bird.image)
        star_mask = pygame.mask.from_surface(self.image)
        offset = (self.rect.x - bird.rect.left, self.rect.y - round(bird.rect.top))
        return bird_mask.overlap(star_mask, offset) is not None
class Pipe:
    GAP = 200
    VELOCITY = 5
    MOVEMENT_RANGE = 100
    MOVEMENT_SPEED = 1  # Initial movement speed

    def __init__(self, x, moving=False):
        self.x = x
        self.moving = moving
        self.moving_up = True
        self.height = 0
        self.top_pos = 0
        self.bottom_pos = 0
        self.PIPE_TOP = PIPE_IMG_REV
        self.PIPE_BOTTOM = PIPE_IMG
        self.passed = False
        self.set_height()
        self.movement_counter = 0

    def set_height(self):
        self.height = random.randrange(50, 300)
        self.top_pos = self.height - self.PIPE_TOP.get_height()
        self.bottom_pos = self.height + self.GAP

    def move(self, score):
        if score >= 10:
            multiplier = (score // 5) * 1.5  # Increase by 1.5 times every 5 points after 20
            self.MOVEMENT_SPEED = min(1 + multiplier, 5)  # Limit the maximum speed increase to 5
        else:
            self.MOVEMENT_SPEED = 1  # Default movement speed before 20 scores

        self.x -= self.VELOCITY
        if self.moving:
            if self.moving_up:
                self.top_pos -= self.MOVEMENT_SPEED
                self.bottom_pos -= self.MOVEMENT_SPEED
                self.movement_counter += self.MOVEMENT_SPEED
                if self.movement_counter >= self.MOVEMENT_RANGE:
                    self.moving_up = False
            else:
                self.top_pos += self.MOVEMENT_SPEED
                self.bottom_pos += self.MOVEMENT_SPEED
                self.movement_counter -= self.MOVEMENT_SPEED
                if self.movement_counter <= -self.MOVEMENT_RANGE:
                    self.moving_up = True

    def draw(self):
        screen.blit(self.PIPE_TOP, (self.x, self.top_pos))
        screen.blit(self.PIPE_BOTTOM, (self.x, self.bottom_pos))

    def collide(self, bird):
        bird_mask = pygame.mask.from_surface(bird.image)
        top_mask = pygame.mask.from_surface(self.PIPE_TOP)
        bottom_mask = pygame.mask.from_surface(self.PIPE_BOTTOM)

        top_offset = (self.x - bird.rect.left, self.top_pos - round(bird.rect.top))
        bottom_offset = (self.x - bird.rect.left, self.bottom_pos - round(bird.rect.top))

        b_point = bird_mask.overlap(bottom_mask, bottom_offset)
        t_point = bird_mask.overlap(top_mask, top_offset)

        if b_point or t_point:
            return True
        return False





def draw_text_with_outline(text, font, color, outline_color, surface, x, y, outline_width):
    for dx in range(-outline_width, outline_width + 1):
        for dy in range(-outline_width, outline_width + 1):
            if dx != 0 or dy != 0:
                outline_surface = font.render(text, True, outline_color)
                surface.blit(outline_surface, (x + dx, y + dy))
    text_surface = font.render(text, True, color)
    surface.blit(text_surface, (x, y))


def draw_lives(lives, icon_img, surface, start_x, y, padding=5):
    for i in range(lives):
        surface.blit(icon_img, (start_x + i * (icon_img.get_width() + padding), y))


def start_screen():
    while True:
        screen.blit(START_SCREEN_IMG, (0, 0))
        draw_text_with_outline("Press SPACE to Start", FONT, WHITE, (0, 0, 0), screen, 250, 450, 2)
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                return


def score_screen(score):
    while True:
        screen.fill(WHITE)
        draw_text_with_outline(f"Your Score: {score}", FONT, (0, 0, 0), WHITE, screen, 300, 250, 2)
        draw_text_with_outline("Press R to Restart", FONT, (0, 0, 0), WHITE, screen, 300, 350, 2)
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_r:
                return

def reset_game():
    global stars, bird_state, bird_state_timer, prevent_star_spawn_timer, star_timer, Pipe

    # 清空星星狀態與數據
    stars = []  # 清空星星列表
    bird_state = "normal"  # 重置鳥的狀態
    bird_state_timer = 0  # 狀態計時器重置
    prevent_star_spawn_timer = 0  # 防止生成星星的計時器重置
    star_timer = 0  # 星星生成計時器重置

    # 恢復管道與背景的速度
    Pipe.VELOCITY = 5  # 默認速度，根據初始遊戲設定



def main():
    start_screen()
    invincibility_timer = 0
    bird = Bird()
    pipes = [Pipe(700)]
    swallows = []
    stars = []  # Reset star list
    star_timer = 0  # Reset star generation timer
    prevent_star_spawn_timer = 0  # Reset prevention timer
    score = 0
    lives = 3
    level = 1
    background = BG_IMG_1
    extra_life_awarded = False
    swallow_timer = 0
    bird_state = "normal"  # Reset bird state
    bird_state_timer = 0  # Reset bird state timer

    running = True
    paused = False
    while running:
        clock.tick(FPS)

        # 等級及背景切換邏輯
        if score > 15 and level == 1:
            level = 2
            pygame.mixer.music.load("sounds/background_2.mp3")
            pygame.mixer.music.set_volume(0.2)
            pygame.mixer.music.play(-1)

        if score > 30:
            background = BG_IMG_2

        screen.blit(background, (0, 0))

        # 處理玩家輸入
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_BACKSPACE:  # 檢測 BACKSPACE 鍵
                    paused = not paused  # 切換暫停狀態
                    if paused:
                        pygame.mixer.music.pause()  # 暫停背景音樂
                    else:
                        pygame.mixer.music.unpause()  # 恢復背景音樂
                if not paused and (event.key == pygame.K_SPACE or event.key == pygame.K_UP):  # 遊戲運行中才能跳躍
                    bird.jump()
                    wing_sound.play()

        if paused:  # 如果遊戲處於暫停狀態，顯示暫停畫面並跳過更新邏輯
            draw_text_with_outline("Paused", FONT, WHITE, (0, 0, 0), screen, SCREEN_WIDTH // 2 - 50, SCREEN_HEIGHT // 2,
                                   2)
            pygame.display.update()
            continue  # 跳過本次迴圈其餘邏輯

        # 更新鳥的狀態
        bird.update()
        bird.draw()

        if invincibility_timer > 0:
            invincibility_timer -= 1

        # 管道邏輯
        rem_pipes = []
        add_pipe = False
        for pipe in pipes:
            pipe.move(score)

            # 管道碰撞檢查
            if pipe.collide(bird) and invincibility_timer == 0 and bird_state != "red":
                lives -= 1
                invincibility_timer = FPS * 5# 2 秒無敵時間
                die_sound.play()

                # 主遊戲循環的結束邏輯
            if lives == 0:
                reset_game()  # 重置所有遊戲數據
                score_screen(score)  # 顯示得分畫面
                main()  # 重新開始遊戲

            if not pipe.passed and pipe.x < bird.rect.x:
                pipe.passed = True
                add_pipe = True
                score += 1
                point_sound.play()

            pipe.draw()

            if pipe.x + pipe.PIPE_TOP.get_width() < 0:
                rem_pipes.append(pipe)

        if add_pipe:
            pipes.append(Pipe(SCREEN_WIDTH, moving=(score > 10)))

        for r in rem_pipes:
            pipes.remove(r)

        # 燕子邏輯
        swallow_timer += 1
        if swallow_timer >= FPS * 3:  # 每 3 秒生成燕子
            swallow_timer = 0
            swallows.extend([Swallow(), Swallow()])  # 一次生成兩隻燕子

        rem_swallows = []
        for swallow in swallows:
            swallow.move()
            swallow.draw()
            if swallow.collide(bird):
                lives -= 1
                rem_swallows.append(swallow)
                die_sound.play()

                if lives == 0:
                    running = False
                    break

            if swallow.rect.x > SCREEN_WIDTH:  # 超出屏幕右邊界則刪除
                rem_swallows.append(swallow)

        for swallow in rem_swallows:
            swallows.remove(swallow)

        # 星星邏輯
        # 星星邏輯
        # 星星邏輯
        if prevent_star_spawn_timer > 0:
            prevent_star_spawn_timer -= 1  # 減少星星生成阻止計時
        else:
            star_timer += 1
            if star_timer >= FPS * 5:  # 每 5 秒生成一顆星星
                star_timer = 0
                star_type = random.choice(["yellow", "red"])
                stars.append(Star(star_type))

        rem_stars = []  # 保存需要移除的星星
        for star in stars:
            star.move()
            star.draw()
            if star.collide(bird):  # 星星碰撞邏輯
                if star.star_type == "yellow":
                    bird_state = "yellow"
                    Pipe.VELOCITY *= 3  # 增加背景和管道速度
                elif star.star_type == "red":
                    bird_state = "red"
                bird_state_timer = FPS * 6  # 狀態持續 6 秒
                prevent_star_spawn_timer = FPS * 10  # 防止 10 秒內生成新星星
                rem_stars.append(star)  # 移除該星星

            # 如果星星超出屏幕左側，則刪除
            if star.rect.x < -50:
                rem_stars.append(star)

        # 移除碰撞或超出螢幕的星星
        for star in rem_stars:
            stars.remove(star)

        # 處理鳥的狀態計時器
        if bird_state_timer > 0:
            bird_state_timer -= 1
        else:
            if bird_state == "yellow":
                Pipe.VELOCITY /= 3  # 恢復正常速度
            bird_state = "normal"  # 恢復普通狀態
        if lives == 0:
            reset_game()  # 重置所有狀態
            score_screen(score)  # 顯示得分畫面
            main()  # 重新開始遊戲

        # 顯示分數和生命值
        draw_text_with_outline(f'Score: {score}', FONT, WHITE, (0, 0, 0), screen, 20, 20, 2)
        draw_lives(lives, LIFE_ICON_IMG, screen, SCREEN_WIDTH - (lives * (LIFE_ICON_SIZE + 5)), 20)

        # 分數超過 30 時增加一條命
        if score >= 30 and not extra_life_awarded:
            lives += 1
            extra_life_awarded = True

        pygame.display.update()

    # 遊戲結束，顯示分數畫面
    score_screen(score)
    main()  # 遊戲結束後重新啟動時，星星邏輯和狀態重置完成


if __name__ == "__main__":
    main()